import cv2
import numpy as np
def video_to_matrix(video_path, max_frame,scale):
    """
    Lit une vidéo et aligne les frames 
    en colonnes pour construire la matrice de données.
    On conserve au plus max_frame images.
    On peut effectuer une scaling sur chaque frame
    
    Paramètre :
    -----------
    	video_path : str
        	     Chemin vers le fichier vidéo (ex: 'video.mp4')
	max_frame : int 
        	    Nombre maximum de frames à conserver
	scale : float
		Facteur d'échelle pour effectuer un scaling des frames
        
    Retours :
    --------
    A : numpy.ndarray
        La matrice de données de taille (m, n) où m = p * q (nombre de pixels)
        et n est le nombre de frames.
    shape_scal : tuple
        Les dimensions des frames après scaling (hauteur, largeur), utiles pour le reshape final.
    """
    # Ouverture du flux vidéo
    cap = cv2.VideoCapture(video_path)
    
    if not cap.isOpened():
        raise ValueError(f"Impossible d'ouvrir la vidéo : {video_path}")
    
    frames_list = []
    shape_scal = None
    while len(frames_list)<max_frame:
        ret, frame = cap.read()
        if not ret:
            break  # Fin de la vidéo
            
        # Conversion en niveaux de gris
        gray_frame = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        # Réduction éventuelle
        if scale != 1.0:
            gray_frame = cv2.resize(
                gray_frame,
                None,
                fx=scale,
                fy=scale,
                interpolation=cv2.INTER_AREA
            )
        
        # Sauvegarde des dimensions de l'image (hauteur p, largeur q)
        if shape_scal is None:
            shape_scal = gray_frame.shape
            
        # Aplatissement de la frame en un vecteur colonne (m,) et ajout à la liste
        frames_list.append(gray_frame.flatten())
        
    # Libération du fichier vidéo
    cap.release()
    
    # Empilement des vecteurs horizontalement pour former une matrice (m, n)
    # On transpose car np.array() empile initialement en lignes (n, m)
    A = np.array(frames_list).T
    
    # Conversion en float pour les calculs de SVD ultérieurs
    A = A.astype(float)
    
    print(f"Matrice A créée avec succès. Dimensions : {A.shape}")
    print(f"Résolution des images : {shape_scal}")
    
    return A, shape_scal
